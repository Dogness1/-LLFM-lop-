select n()AND+#00;
